
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/serverless-mcp-server.ts
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { toFetchResponse, toReqRes } from "fetch-to-node";

// netlify/mcp-server/index.ts
import { z } from "zod";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
var setupMCPServer = () => {
  const server = new McpServer(
    {
      name: "stateless-server",
      version: "1.0.0"
    },
    { capabilities: { logging: {} } }
  );
  server.prompt(
    "greeting-template",
    "A simple greeting prompt template",
    {
      name: z.string().describe("Name to include in greeting")
    },
    async ({ name }) => {
      return {
        messages: [
          {
            role: "user",
            content: {
              type: "text",
              text: `Please greet ${name} in a friendly manner.`
            }
          }
        ]
      };
    }
  );
  server.tool(
    "start-notification-stream",
    "Starts sending periodic notifications for testing resumability",
    {
      interval: z.number().describe("Interval in milliseconds between notifications").default(100),
      count: z.number().describe("Number of notifications to send (0 for 100)").default(10)
    },
    async ({ interval, count }, { sendNotification }) => {
      const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
      let counter = 0;
      while (count === 0 || counter < count) {
        counter++;
        try {
          await sendNotification({
            method: "notifications/message",
            params: {
              level: "info",
              data: `Periodic notification #${counter} at ${(/* @__PURE__ */ new Date()).toISOString()}`
            }
          });
        } catch (error) {
          console.error("Error sending notification:", error);
        }
        await sleep(interval);
      }
      return {
        content: [
          {
            type: "text",
            text: `Started sending periodic notifications every ${interval}ms`
          }
        ]
      };
    }
  );
  server.resource(
    "greeting-resource",
    "https://example.com/greetings/default",
    { mimeType: "text/plain" },
    async () => {
      return {
        contents: [
          {
            uri: "https://example.com/greetings/default",
            text: "Hello, world!"
          }
        ]
      };
    }
  );
  return server;
};

// netlify/functions/serverless-mcp-server.ts
var serverless_mcp_server_default = async (req) => {
  try {
    if (req.method === "POST") {
      return handleMCPPost(req);
    } else if (req.method === "GET") {
      return handleMCPGet();
    } else if (req.method === "DELETE") {
      return handleMCPDelete();
    } else {
      return new Response("Method not allowed", { status: 405 });
    }
  } catch (error) {
    console.error("MCP error:", error);
    return new Response(
      JSON.stringify({
        jsonrpc: "2.0",
        error: {
          code: -32603,
          message: "Internal server error"
        },
        id: null
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" }
      }
    );
  }
};
async function handleMCPPost(req) {
  const { req: nodeReq, res: nodeRes } = toReqRes(req);
  const server = setupMCPServer();
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: void 0
  });
  await server.connect(transport);
  const body = await req.json();
  await transport.handleRequest(nodeReq, nodeRes, body);
  nodeRes.on("close", () => {
    console.log("Request closed");
    transport.close();
    server.close();
  });
  return toFetchResponse(nodeRes);
}
function handleMCPGet() {
  console.log("Received GET MCP request");
  return new Response(
    JSON.stringify({
      jsonrpc: "2.0",
      error: {
        code: -32e3,
        message: "Method not allowed."
      },
      id: null
    }),
    {
      status: 405,
      headers: { "Content-Type": "application/json" }
    }
  );
}
function handleMCPDelete() {
  console.log("Received DELETE MCP request");
  return new Response(
    JSON.stringify({
      jsonrpc: "2.0",
      error: {
        code: -32e3,
        message: "Method not allowed."
      },
      id: null
    }),
    {
      status: 405,
      headers: { "Content-Type": "application/json" }
    }
  );
}
var config = {
  path: "/mcp"
};
export {
  config,
  serverless_mcp_server_default as default
};
